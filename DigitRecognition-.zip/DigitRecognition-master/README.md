I have made a project to recognise a digit in an image.Here is the video that will explain you.

https://www.youtube.com/watch?v=si4HSgneKY0
Data set is downloaded from MNIST website here is a link
http://yann.lecun.com/exdb/mnist/
I have also uploaded a python code to convert data set to csv file.
