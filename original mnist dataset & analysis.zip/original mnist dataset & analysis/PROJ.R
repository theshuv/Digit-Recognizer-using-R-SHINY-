install.packages("mnis")
install.packages("idx2r")

install.packages("R.utils")
R.utils::gunzip("F:/dataset imag/t10k-images-idx3-ubyte.gz")   
R.utils::gunzip("F:/dataset imag/train-images-idx3-ubyte.gz")
R.utils::gunzip("F:/dataset imag/t10k-labels-idx1-ubyte.gz")     
R.utils::gunzip("F:/dataset imag/train-labels-idx1-ubyte.gz") 




# helper function for visualization
show_digit = function(arr784, col = gray(12:1 / 12), ...) {
  image(matrix(as.matrix(arr784[-785]), nrow = 28)[, 28:1], col = col, ...)
}

# load image files
load_image_file = function(filename) {
  ret = list()
  f = file(filename, 'rb')
  readBin(f, 'integer', n = 1, size = 4, endian = 'big')
  n    = readBin(f, 'integer', n = 1, size = 4, endian = 'big')
  nrow = readBin(f, 'integer', n = 1, size = 4, endian = 'big')
  ncol = readBin(f, 'integer', n = 1, size = 4, endian = 'big')
  x = readBin(f, 'integer', n = n * nrow * ncol, size = 1, signed = FALSE)
  close(f)
  data.frame(matrix(x, ncol = nrow * ncol, byrow = TRUE))
}

# load label files
load_label_file = function(filename) {
  f = file(filename, 'rb')
  readBin(f, 'integer', n = 1, size = 4, endian = 'big')
  n = readBin(f, 'integer', n = 1, size = 4, endian = 'big')
  y = readBin(f, 'integer', n = n, size = 1, signed = FALSE)
  close(f)
  y
}

# load images
train = load_image_file("F:/dataset imag/train-images-idx3-ubyte")
test  = load_image_file("F:/dataset imag/t10k-images-idx3-ubyte")

# load labels
train$y = as.factor(load_label_file("F:/dataset imag/train-labels-idx1-ubyte"))
test$y  = as.factor(load_label_file("F:/dataset imag/t10k-labels-idx1-ubyte"))

# view test image
show_digit(train[10000, ])
show_digit(train[15999, ])
#show_digit(train[10003, ])

# testing classification on subset of training data
install.packages("randomforest")
# syntax:-  randomForest(formula, data)
# 1.formula is a formula describing the predictor and response variables.(y~.)
# 2.data is the name of the data set used.



fit = randomForest::randomForest(y ~ ., data = train[1:1000, ])
print(fit)
fit$confusion
test_pred = predict(fit, test)

mean(test_pred == test$y)
table(predicted = test_pred, actual = test$y)

